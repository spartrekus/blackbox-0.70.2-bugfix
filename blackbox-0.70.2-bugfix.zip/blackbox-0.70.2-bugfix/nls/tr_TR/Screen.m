$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen : X sunucusunu sorgularken hata oldu.\n  \
%s ekran�nda ba�ka bir pencere y�neticisi �al���yor gibi.\n
$ #ManagingScreen
# BScreen::BScreen : %d ekran�, 0x%lx g�r�n�m�yle , %d derinli�iyle\n
$ #FontLoadFail
# BScreen::LoadStyle() : '%s' yaz� tipi y�klenemedi.\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): �nayarl� yaz� tipi y�klenemedi.\n
$ #EmptyMenuFile
# %s : bo� m�n� dosyas�\n
$ #xterm
# X komutas�
$ #Restart
# Yeniden ba�la
$ #Exit
# ��k
$ #EXECError
# BScreen::parseMenuFile : [exec] hatas�, m�n� yaftas� ve/yada komuta belirlenmedi\n
$ #EXITError
# BScreen::parseMenuFile : [exit] hatas�, m�n� yaftas� belirlenmedi\n
$ #STYLEError
# BScreen::parseMenuFile : [style] hatas�, m�n� yaftas� ve/yada dosya ad� belirlenmedi\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] hatas�, m�n� yaftas� belirlenmedi\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] hatas�, dosya ad� belirlenmedi\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] hatas�, '%s' vasat bir dosya de�il\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] hatas�, m�n� yaftas� belirlenmedi\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] hatas�, m�n� yaftas� belirlenmedi\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] hatas�, m�n� yaftas� belirlenmedi\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] hatas�, dizin ad� belirlenmedi\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] hatas�, '%s' bir dizin \
de�ildir\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] hatas�, '%s' var de�il\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] hatas�, m�n� yaftas� belirlenmedi\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# Y: %4d x E: %4d
