$set 7 #Slit

$ #SlitTitle
# Slit
$ #SlitDirection
# Slit y�n�
$ #SlitPlacement
# Slit yerle�imi
