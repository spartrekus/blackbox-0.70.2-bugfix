$set 12 #Workspacemenu

$ #WorkspacesTitle
# Masa�stleri
$ #NewWorkspace
# Yeni bir masa�st�
$ #RemoveLast
# Son masa�st�n� sil
