$set 1 #BaseDisplay

$ #XError
# %s:  X error: %s(%d) c�digo de operaci�n %d/%d\n  recurso 0x%lx\n
$ #SignalCaught
# %s: se�al %d atrapada\n
$ #ShuttingDown
# apagando\n
$ #Aborting
# abortando... grabando 'core'\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: fall� la conexi�n al servidor de X.\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: no pude marcar la conexi�n de despliegue como close-on-exec\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): quitando ventana err�nea de la lista de eventos\n
