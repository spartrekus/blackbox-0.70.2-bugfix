$set 7 #Slit

$ #SlitTitle
# Slit
$ #SlitDirection
# Direcci�n de la Slit
$ #SlitPlacement
# Ubicaci�n de la Slit
