$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: geen schermen gevonden om te managen, afgesloten\n
$ #MapRequest
# Blackbox::process_event: MapRequest voor 0x%lx\n
