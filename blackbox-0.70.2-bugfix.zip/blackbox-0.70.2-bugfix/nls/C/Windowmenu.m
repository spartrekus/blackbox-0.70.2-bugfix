$set 10 #Windowmenu

$ #SendTo
# Send To ...
$ #Shade
# Shade
$ #Iconify
# Iconify
$ #Maximize
# Maximize
$ #Raise
# Raise
$ #Lower
# Lower
$ #Stick
# Stick
$ #KillClient
# Kill Client
$ #Close
# Close
