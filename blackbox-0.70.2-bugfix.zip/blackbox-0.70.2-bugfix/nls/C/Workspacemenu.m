$set 12 #Workspacemenu

$ #WorkspacesTitle
# Workspaces
$ #NewWorkspace
# New Workspace
$ #RemoveLast
# Remove Last
