$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: izveidoju 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: XGetWindowAttributres neizdev�s\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: nevaru atrast ekr�nu saknes logam 0x%lx\n
$ #Unnamed
# Nenosaukts
$ #MapRequest
# BlackboxWindow::mapRequestEvent() priek� 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() priek� 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::unmapnotifyEvent: p�rvec�ka 0x%lx uz 0x%lx\n
