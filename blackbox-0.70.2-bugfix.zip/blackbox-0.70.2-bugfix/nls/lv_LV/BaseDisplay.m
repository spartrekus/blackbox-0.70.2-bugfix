$set 1 #BaseDisplay

$ #XError
# %s:  X k��da: %s(%d) opkodi %d/%d\n  resurss 0x%lx\n
$ #SignalCaught
# %s: sa��ma sign�lu %d\n
$ #ShuttingDown
# beidz�jos\n
$ #Aborting
# p�rtraucu... izmetu pamatatmi�u\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: savienojums ar X serveri neizdev�s.\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: nevar�ju nomar��t displeja savienojumu k� aizv�rt-pie-izpildes\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): iz�emu slikto logu no notikumu rindas\n
