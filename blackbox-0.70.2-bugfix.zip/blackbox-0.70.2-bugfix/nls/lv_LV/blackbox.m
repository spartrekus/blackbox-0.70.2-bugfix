$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: p�rvald�mi logi nav atrasti, p�rtraucu\n
$ #MapRequest
# Blackbox::process_event: Kartes Piepras�jums priek� 0x%lx\n
