$set 15 #Common

$ #Yes
# Igen
$ #No
# Nem

$ #DirectionTitle
# Ir�ny
$ #DirectionHoriz
# V�zszintes
$ #DirectionVert
# F�gg�leges

$ #AlwaysOnTop
# Mindig az el�t�rben

$ #PlacementTitle
# Elhelyez�s
$ #PlacementTopLeft
# Bal fel�l
$ #PlacementCenterLeft
# Bal k�z�pen
$ #PlacementBottomLeft
# Bal lent
$ #PlacementTopCenter
# K�z�pen fel�l
$ #PlacementBottomCenter
# K�z�pen lent
$ #PlacementTopRight
# Jobb fent
$ #PlacementCenterRight
# Jobb k�z�pen
$ #PlacementBottomRight
# Jobb lent

$ #AutoHide
# Aut�matikus elrejt�s
