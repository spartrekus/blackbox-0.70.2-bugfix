$set 10 #Windowmenu

$ #SendTo
# Manda in ...
$ #Shade
# Arrotola
$ #Iconify
# Riduci a Icona
$ #Maximize
# Ingrandisci
$ #Raise
# Alza
$ #Lower
# Abbassa
$ #Stick
# Fissa
$ #KillClient
# Uccidi Programma
$ #Close
# Chiudi
