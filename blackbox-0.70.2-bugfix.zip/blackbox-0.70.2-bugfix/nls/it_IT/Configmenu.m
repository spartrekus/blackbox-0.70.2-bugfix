$set 3 #Configmenu

$ #ConfigOptions
# Opzioni di Configurazione
$ #FocusModel
# Modalita' Focus
$ #WindowPlacement
# Posizionamento Finestra
$ #ImageDithering
# Dithering dell'immagine
$ #OpaqueMove
# Movimento Opaco della finestra
$ #FullMax
# Massimo Ingrandimento
$ #FocusNew
# Attiva Focus alle nuove Finestre
$ #FocusLast
# Attiva Focus al cambio dell'Area di Lavoro
$ #ClickToFocus
# Clicca per il Focus
$ #SloppyFocus
# Focus Intelligente (Sloppy)
$ #AutoRaise
# Sollevamento Finestra Automatico
$ #SmartRows
# Posizionamento Intelligente (Righe)
$ #SmartCols
# Posizionamento Intelligente (Colonne)
$ #Cascade
# Posizionamento a Cascata
$ #LeftRight
# da Sinistra a Destra
$ #RightLeft
# da Destra a Sinistra
$ #TopBottom
# dall'Alto in Basso
$ #BottomTop
# dal Basso in Alto
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
