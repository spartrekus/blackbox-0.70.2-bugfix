$set 15 #Common

$ #Yes
# Si
$ #No
# No

$ #DirectionTitle
# Direzione
$ #DirectionHoriz
# Orizzontale
$ #DirectionVert
# Verticale

$ #AlwaysOnTop
# Sempre in primo piano

$ #PlacementTitle
# Posizionamento
$ #PlacementTopLeft
# in Alto a Sinistra
$ #PlacementCenterLeft
# al Centro a Sinistra
$ #PlacementBottomLeft
# in Basso a Sinistra
$ #PlacementTopCenter
# in Alto al Centro
$ #PlacementBottomCenter
# in Basso al Centro
$ #PlacementTopRight
# in Alto a Destra
$ #PlacementCenterRight
# al Centro a Destra
$ #PlacementBottomRight
# in Basso a Destra

$ #AutoHide
# Nascondi Automaticamente
