$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: e' accaduto un errore mentre si interrogava il server X.\n  \
un'altro gestore di finestre e' attualmente in esecuzione sul display %s.\n
$ #ManagingScreen
# BScreen::BScreen: gestendo schermo %d usando visuale 0x%lx, depth %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): impossibile caricare il font '%s'\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): impossibile caricare il font di default.\n
$ #EmptyMenuFile
# %s: file menu vuoto\n
$ #xterm
# xterm
$ #Restart
# Riavvia
$ #Exit
# Esci
$ #EXECError
# BScreen::parseMenuFile: [exec] errore, nessuna voce nel menu e/o comando definito\n
$ #EXITError
# BScreen::parseMenuFile: [exit] errore, nessuna voce nel menu definita\n
$ #STYLEError
# BScreen::parseMenuFile: [style] errore, nessuna voce nel menu e/o file\
definto\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] errore, nessuna voce nel menu definta\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] errore, nessun file definito\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] errore, '%s' non � un file regolare\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] errore, nessuna voce nel menu definta\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] errore, nessuna voce nel menu definta\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] errore, nessuna voce nel menu definta\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] errore, nessuna cartella definita\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] errore, '%s' non e' una \
cartella\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] errore, '%s' non esiste\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] errore, nessuna voce nel menu definita\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# W: %4d x H: %4d

