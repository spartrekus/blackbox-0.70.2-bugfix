$set 7 #Slit

$ #SlitTitle
# Slit
$ #SlitDirection
# Direzione Slit
$ #SlitPlacement
# Posizionamento Slit
