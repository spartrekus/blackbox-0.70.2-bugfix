$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: errore creando la pixmap\n
$ #ErrorCreatingXImage
# BImage::renderXImage: errore creando XImage\n
$ #UnsupVisual
# BImage::renderXImage: visuale non supportata\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: errore creando la pixmap\n
$ #InvalidColormapSize
# BImageControl::BImageControl: grandezza della mappa di colori non valida %d (%d/%d/%d) - riduzione\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: errore di assegnazione mappa di colori\n
$ #ColorAllocFail
# BImageControl::BImageControl: fallita l'assegnazione del colore %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl: pixmap cache - rilascio %d pixmaps\n
$ #PixmapCacheLarge
# BImageControl::renderImage: la cache e' larga, forzo la pulitura\n
$ #ColorParseError
# BImageControl::getColor: errore di analisi del colore: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: errore di assegnazione del colore: '%s'\n
