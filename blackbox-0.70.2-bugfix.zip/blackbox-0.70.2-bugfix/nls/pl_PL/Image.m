$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: wyst�pi� b��d podczas tworzenia pixmapy\n
$ #ErrorCreatingXImage
# BImage::renderXImage: wyst�pi� b��d podczas tworzenia obiektu XImage\n
$ #UnsupVisual
# BImage::renderXImage: brak akceptowanego sposobu obs�ugi kolor�w\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: wyst�pi� b��d podczas tworzenia pixmapy\n
$ #InvalidColormapSize
# BImageControl::BImageControl: z�y rozmiar mapy kolor�w %d (%d/%d/%d) - \
redukuje\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: b��d alokacji mapy kolor�w\n
$ #ColorAllocFail
# BImageControl::BImageControl: alokacja koloru %d/%d/%d nieudana\n
$ #PixmapRelease
# BImageControl::BImageControl: pixmap cache - zwalniam %d pixmap(y)\n
$ #PixmapCacheLarge
# BImageControl::renderImage: du�a pami�� cache, wymuszam czyszczenie\n
$ #ColorParseError
# BImageControl::getColor: wyst�pi� b��d podczas t�umaczenia koloru: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: wyst�pi� b��d podczas alokacji koloru: '%s'\n
