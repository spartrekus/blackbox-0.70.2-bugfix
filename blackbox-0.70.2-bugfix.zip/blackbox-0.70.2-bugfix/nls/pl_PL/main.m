$set 14 #main

$ #RCRequiresArg
# b��d: opcja '-rc' wymaga podania argumentu\n
$ #DISPLAYRequiresArg
# b��d: opcja '-display' wymaga podania argumentu\n
$ #WarnDisplaySet
# ostrze�enie: nie mo�na ustawi� zmiennej �rodowiskowej 'DISPLAY'\n
$ #Usage
# Blackbox %s : (c) 2001 - 2002 Sean 'Shaleh' Perry\n\
  \t\t\t 1997 - 2000, 2002 Brad Hughes\n\n\
  -display <string>\t\tpo��cz z podanym panelem graficznym.\n\
  -rc <string>\t\t\tu�yj innego pliku konfiguracyjnego.\n\
  -version\t\t\twy�wietl wersj� i zako�cz dzia�anie programu.\n\
  -help\t\t\t\twy�wietl ten komunikat.\n\n
$ #CompileOptions
# Opcje u�yte podczas kompilacji:\n\
  Debugging\t\t\t%s\n\
  Shape:\t\t\t%s\n\
  8bpp Ordered Dithering:\t%s\n\n
