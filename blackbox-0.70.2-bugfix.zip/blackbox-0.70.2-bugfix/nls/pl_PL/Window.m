$set 9 #Window

$ #Creating
# BlackboxWindow::BlackboxWindow: tworz� 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: nieudane wywo�anie XGetWindowAttributres\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: brak ekranu dla g��wnego okna 0x%lx\n
$ #Unnamed
# Bez nazwy 
$ #MapRequest
# BlackboxWindow::mapRequestEvent() dla 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() dla 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: zmieniam rodzica 0x%lx na 0x%lx\n
