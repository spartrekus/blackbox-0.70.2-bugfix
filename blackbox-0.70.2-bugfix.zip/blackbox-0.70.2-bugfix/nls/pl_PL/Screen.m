$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: wyst�pi� b��d podczas kontaktowania si� z X serwerem.\n\
Inny mened�er okien obs�uguje panel graficzny %s.\n
$ #ManagingScreen
# BScreen::BScreen: obs�uguj� ekran %d visual 0x%lx, g��bia kolor�w %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): nie mo�na za�adowa� czcionki '%s'\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): nie mo�na za�adowa� domy�lnej czcionki.\n
$ #EmptyMenuFile
# %s: plik menu jest pusty\n
$ #xterm
# xterm
$ #Restart
# Restart
$ #Exit
# Wyj�cie
$ #EXECError
# BScreen::parseMenuFile: [exec] b��d, brak etykiety menu i/lub komendy\n
$ #EXITError
# BScreen::parseMenuFile: [exit] b��d, brak etykiety menu\n
$ #STYLEError
# BScreen::parseMenuFile: [style] b��d, brak etykiety menu i/lub nazwy pliku\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] b��d, brak etykiety menu\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] b��d, brak nazwy pliku\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] b��d, '%s' nie jest zwyk�ym plikiem\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] b��d, brak etykiety menu\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] b��d, brak etykiety menu\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] b��d, brak etykiety menu\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] b��d, brak nazwy katalogu\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] b��d, '%s' nie jest \
katalogiem\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] b��d, '%s' nie istnieje\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] b��d, brak etykiety menu\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# S: %4d x W: %4d

