$set 1 #BaseDisplay

$ #XError
# %s:  X fejl: %s(%d) kode %d/%d\n  resource 0x%lx\n
$ #SignalCaught
# %s: signal %d fanget\n
$ #ShuttingDown
# lukker ned\n
$ #Aborting
# Avbryder... dumper kernen\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: tilslutning til X server mislykkedes.\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: kunne ikke markere sk�rmtilslutning som luk-ved-afslut\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): fjerner d�rligt vindue fra h�ndelsesk�en\n
