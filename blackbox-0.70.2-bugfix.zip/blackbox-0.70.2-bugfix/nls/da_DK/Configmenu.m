$set 3 #Configmenu

$ #ConfigOptions
# Indstillinger
$ #FocusModel
# Fokus Model
$ #WindowPlacement
# Vindueplacering
$ #ImageDithering
# Billede Dithering
$ #OpaqueMove
# Uklar vinduesflytning
$ #FullMax
# Fuld maximering
$ #FocusNew
# Fokus nyt vindue
$ #FocusLast
# Fokus vindue ved skrivebords �ndring
$ #DisableBindings
# Deaktiver tastebindinger med Scroll Lock
$ #ClickToFocus
# Klik for fokus
$ #SloppyFocus
# Dovent fokus
$ #AutoRaise
# H�v automatisk
$ #ClickRaise
# Klik for at h�ve
$ #SmartRows
# Intelligent placering (R�kker)
$ #SmartCols
# Intelligent placering (S�jler)
$ #Cascade
# Kaskade placering
$ #LeftRight
# Fra venstre mod h�jre
$ #RightLeft
# Fra h�jre mod venstre
$ #TopBottom
# Oppefra
$ #BottomTop
# Nedefra
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
