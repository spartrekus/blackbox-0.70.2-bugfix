$set 12 #Workspacemenu

$ #WorkspacesTitle
# Skrivebord
$ #NewWorkspace
# Nytt skrivebord
$ #RemoveLast
# Fjern siste
