$set 14 #main

$ #RCRequiresArg
# feil: '-rc' krever et argument\n
$ #DISPLAYRequiresArg
# feil: '-display' krever et argument\n
$ #WarnDisplaySet
# advarsel: kunne ikke sette 'DISPLAY' milj�variabelen\n
$ #Usage
# Blackbox %s : (c) 2001 - 2002 Sean 'Shaleh' Perry\n\
  \t\t\t 1997 - 2000, 2002 Brad Hughes\n\n\
  -display <streng>\t\tbruk skjermtilkobling.\n\
  -rc <streng>\t\t\tbrug alternativ ressursfil.\n\
  -version\t\t\tvis versjonsnummeret og avslutt.\n\
  -help\t\t\t\tvis denne hjelpeteksten og avslutt.\n\n
$ #CompileOptions
# Kompileret med:\n\
  Debugging\t\t\t%s\n\
  Shape:\t\t\t%s\n\
  8bpp Ordered Dithering:\t%s\n\n
