$set 15 #Common

$ #Yes
# Ja
$ #No
# Nei

$ #DirectionTitle
# Retning
$ #DirectionHoriz
# Horisontal
$ #DirectionVert
# Vertikal

$ #AlwaysOnTop
# Alltid �verst

$ #PlacementTitle
# Plassering
$ #PlacementTopLeft
# �verst til venstre
$ #PlacementCenterLeft
# Venstre i midten
$ #PlacementBottomLeft
# Nederst til venstre
$ #PlacementTopCenter
# �verst i midten
$ #PlacementBottomCenter
# Nederst i midten
$ #PlacementTopRight
# �verst til h�yre
$ #PlacementCenterRight
# H�yre i midten
$ #PlacementBottomRight
# Nederst til h�yre

$ #AutoHide
# Skjul automatisk
