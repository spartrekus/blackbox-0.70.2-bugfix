$set 3 #Configmenu

$ #ConfigOptions
# Configura��es
$ #FocusModel
# Modelo de Foco
$ #WindowPlacement
# Posicionamento das Janelas
$ #ImageDithering
# Simula��o de Cores em Imagens
$ #OpaqueMove
# Movimento Opaco de Janelas
$ #FullMax
# Maximiza��o Total
$ #FocusNew
# Foco em Novas Janelas
$ #FocusLast
# Foco na Ultima Janela Da Area de Trabalho
$ #DisableBindings
# Disabilitar A��es com Scroll Lock
$ #ClickToFocus
# Clicar para Focar
$ #SloppyFocus
# Apontar para Focar
$ #AutoRaise
# Auto-sobrepor
$ #ClickRaise
# Click Raise
$ #SmartRows
# Organizar Rapido (Linha)
$ #SmartCols
# Organizar Rapido (Coluna)
$ #Cascade
# Organizar em Cascata
$ #LeftRight
# Esquerda para Direita
$ #RightLeft
# Direita para Esquerda
$ #TopBottom
# Cima para Baixo
$ #BottomTop
# Baixo para Cima
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
