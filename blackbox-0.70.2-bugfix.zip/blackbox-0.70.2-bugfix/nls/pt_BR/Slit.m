$set 7 #Slit

$ #SlitTitle
# Slit
$ #SlitDirection
# Dire��o do Slit
$ #SlitPlacement
# Posicionamento do Slit
