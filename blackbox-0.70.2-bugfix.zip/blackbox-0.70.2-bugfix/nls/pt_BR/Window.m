$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: criando 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: XGetWindowAttributres falhou\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: impossivel encontrar tela para janela principal 0x%lx\n
$ #Unnamed
# Sem Nome
$ #MapRequest
# BlackboxWindow::mapRequestEvent() para 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() para 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: reparent 0x%lx para 0x%lx\n
