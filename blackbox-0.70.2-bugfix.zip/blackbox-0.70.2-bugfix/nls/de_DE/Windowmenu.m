$set 10 #Windowmenu

$ #SendTo
# Senden an...
$ #Shade
# Aufrollen
$ #Iconify
# Verkleinern
$ #Maximize
# Vergr��ern
$ #Raise
# In den Vordergrund
$ #Lower
# In den Hintergrund
$ #Stick
# Immer sichtbar
$ #KillClient
# Abbrechen
$ #Close
# Schliessen
