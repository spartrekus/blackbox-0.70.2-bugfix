$set 12 #Workspacemenu

$ #WorkspacesTitle
# Arbeitspl�tze
$ #NewWorkspace
# Neuer Arbeitsplatz
$ #RemoveLast
# Letzten Arbeitsplatz l�schen
