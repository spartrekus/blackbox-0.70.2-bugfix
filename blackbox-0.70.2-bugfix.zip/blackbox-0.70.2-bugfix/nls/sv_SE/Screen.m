$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: ett fel intr�ffade under en f�rfr�gan till X servern.\n  \
en annan f�nsterhanterare k�rs redan p� sk�rmen %s.\n
$ #ManagingScreen
# BScreen::BScreen: hanterar sk�rm %d med visuell 0x%lx, f�rgdjup %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): kunde inte ladda font '%s'\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): kunde inte ladda standardfont.\n
$ #EmptyMenuFile
# %s: tom menyfil\n
$ #xterm
# xterm
$ #Restart
# Starta om
$ #Exit
# Avsluta
$ #EXECError
# BScreen::parseMenuFile: [exec] fel, ingen menyetikett och/eller kommando definierat\n
$ #EXITError
# BScreen::parseMenuFile: [exit] fel, ingen menyetikett definierad\n
$ #STYLEError
# BScreen::parseMenuFile: [style] fel, ingen menyetikett och/eller filnamn definierat\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] fel, ingen menyetikett definierad\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] fel, inget filnamn definierat\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] fel, '%s' �r inte en vanlig fil\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] fel, ingen menyetikett definierad\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] fel, ingen menyetikett definiera\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] fel, ingen menyetikett definierad\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] fel, ingen katalog definierad\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] fel, '%s' �r inte en katalog\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] fel, '%s' existerar inte\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] fel, ingen menyetikett definierad\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# W: %4d x H: %4d

