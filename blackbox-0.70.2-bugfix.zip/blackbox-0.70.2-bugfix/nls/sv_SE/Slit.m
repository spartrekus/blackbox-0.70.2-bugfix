$set 7 #Slit

$ #SlitTitle
# Slit
$ #SlitDirection
# Slitriktning
$ #SlitPlacement
# Slitplacering
