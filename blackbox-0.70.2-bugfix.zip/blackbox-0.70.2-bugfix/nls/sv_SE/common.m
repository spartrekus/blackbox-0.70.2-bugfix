$set 15 #Common

$ #Yes
# Ja
$ #No
# Nej

$ #DirectionTitle
# Riktning
$ #DirectionHoriz
# Horisontell
$ #DirectionVert
# Vertikal

$ #AlwaysOnTop
# Alltid �verst

$ #PlacementTitle
# Placering
$ #PlacementTopLeft
# Uppe till v�nster
$ #PlacementCenterLeft
# Mitten till v�nster
$ #PlacementBottomLeft
# Nere till v�nster
$ #PlacementTopCenter
# Uppe i mitten
$ #PlacementBottomCenter
# Nere i mitten
$ #PlacementTopRight
# Uppe till h�ger
$ #PlacementCenterRight
# Mitten till h�ger
$ #PlacementBottomRight
# Nere till h�ger

$ #AutoHide
# G�m automatiskt
