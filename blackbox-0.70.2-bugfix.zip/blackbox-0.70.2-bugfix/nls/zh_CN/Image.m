$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: ����pixmap����\n
$ #ErrorCreatingXImage
# BImage::renderXImage: ����XImage����\n
$ #UnsupVisual
# BImage::renderXImage: unsupported visual\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: ����pixmap����\n
$ #InvalidColormapSize
# BImageControl::BImageControl: invalid colormap size %d (%d/%d/%d) - reducing\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: error allocating colormap\n
$ #ColorAllocFail
# BImageControl::BImageControl: failed to alloc color %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl: pixmap cache - releasing %d pixmaps\n
$ #PixmapCacheLarge
# BImageControl::renderImage: cache is large, forcing cleanout\n
$ #ColorParseError
# BImageControl::getColor: color parse error: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: color alloc error: '%s'\n
