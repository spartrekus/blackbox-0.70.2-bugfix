$set 14 #main

$ #RCRequiresArg
# eroare: '-rc' necesita inca un parametru\n
$ #DISPLAYRequiresArg
# eroare: '-display' necesita inca un parametru\n
$ #WarnDisplaySet
# atentionare: nu am putut crea variabila de mediu 'DISPLAY'\n
$ #Usage
# Blackbox %s : (c) 2001 - 2002 Sean 'Shaleh' Perry\n\
  \t\t\t 1997 - 2000, 2002 Brad Hughes\n\n\
  -display <sir>\t\tconexiunea la ecran.\n\
  -rc <sir>\t\t\tfisier de configurare.\n\
  -version\t\t\tafiseaza versiunea.\n\
  -help\t\t\t\tafiseaza acest mesaj.\n\n
$ #CompileOptions
# Optiuni stabilite la compilare:\n\
  Depanare\t\t\t%s\n\
  Forma:\t\t\t%s\n\
  Intretesere ordonata pentru 8bpp:\t%s\n\n
