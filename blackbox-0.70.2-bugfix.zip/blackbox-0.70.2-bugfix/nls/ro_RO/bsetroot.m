$set 16 #bsetroot

$ #MustSpecify
# %s: eroare: trebuie specificata cel putin una dintre optiunile:\n\
             -solid, -mod, -gradient\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <sir>           conexiunea la ecran\n\
  -mod <x> <y>             model\n\
  -foreground, -fg <color> culoare plan apropiat pentru model\n\
  -background, -bg <color> culoare plan indepartat pentru model\n\n\
  -gradient <texture>      degrade\n\
  -from <color>            culoare de inceput pentru degrade\n\
  -to <color>              culoare de sfirsit pentru degrade\n\n\
  -solid <color>           culoare uniforma\n\n\
  -help                    acest mesaj\n
