$set 3 #Configmenu

$ #ConfigOptions
# Configuratie
$ #FocusModel
# Tehnica de focalizare
$ #WindowPlacement
# Asezarea ferestrelor
$ #ImageDithering
# Intretesere imagini
$ #OpaqueMove
# Ferestrele se misca opac
$ #FullMax
# Marirea maxima ocupa tot ecranul
$ #FocusNew
# Focalizare ferestre noi
$ #FocusLast
# Focalizare la schimbarea zonei de lucru
$ #DisableBindings
# Scroll Lock dezactiveaza combinatiile de taste
$ #ClickToFocus
# Focalizare prin click
$ #SloppyFocus
# Focalizare prin cursor
$ #AutoRaise
# Ridicare automata
$ #ClickRaise
# Ridicare prin click
$ #SmartRows
# Aranjare automata (pe rinduri)
$ #SmartCols
# Aranjare automata (pe coloane)
$ #Cascade
# Aranjare in cascada
$ #LeftRight
# De la stanga la dreapta
$ #RightLeft
# De la dreapta la stanga
$ #TopBottom
# De sus in jos
$ #BottomTop
# De jos in sus
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
