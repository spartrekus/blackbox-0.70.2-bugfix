$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: chyba pri vytv�ran� pixmapy\n
$ #ErrorCreatingXImage
# BImage::renderXImage: chyba pri vytv�ran� XImage\n
$ #UnsupVisual
# BImage::renderXImage: nepodporovan� zobrazenie\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: chyba pri vytv�ran� pixmapy\n
$ #InvalidColormapSize
# BImageControl::BImageControl: chybn� ve�kost colormapy %d (%d/%d/%d) - redukuje sa\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: chyba pri alokovan� colormapy\n
$ #ColorAllocFail
# BImageControl::BImageControl: chyba pri alokovan� farby %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl: vyrovn�vacia pam� pre pixmapy - uvo��uje sa %d pixm�p\n
$ #PixmapCacheLarge
# BImageControl::renderImage: vyrovn�vacia pam� je pr�li� ve�k�, vyn�ten� vypr�zdnenie\n
$ #ColorParseError
# BImageControl::getColor: chyba pri anal�ze farby: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: chyba pri alokovan� farby: '%s'\n
