$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: nena�li sa spravovate�n� obrazovky, ru�� sa\n
$ #MapRequest
# Blackbox::process_event: MapRequest pre 0x%lx\n
