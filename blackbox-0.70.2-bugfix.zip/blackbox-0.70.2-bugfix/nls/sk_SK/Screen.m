$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: pri dopytovan� X servera nastala chyba.\n  \
na displeji je pr�ve spusten� �al�� spr�vca okien %s.\n
$ #ManagingScreen
# BScreen::BScreen: riadiaca obrazovka %d pou��va zobrazenie 0x%lx, h�bka %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): nie je mo�n� nahra� font '%s'\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): nie je mo�n� nahra� predvolen� font.\n
$ #EmptyMenuFile
# %s: pr�zdny menu s�bor\n
$ #xterm
# xterm
$ #Restart
# Re�tart
$ #Exit
# Koniec
$ #EXECError
# BScreen::parseMenuFile: [exec] chyba, nedefinovan� titulok menu a/alebo pr�kaz\n
$ #EXITError
# BScreen::parseMenuFile: [exit] chyba, nedefinovan� titulok menu\n
$ #STYLEError
# BScreen::parseMenuFile: [style] chyba, nedefinovan� titulok menu a/alebo n�zov s�boru\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] chyba, nedefinovan� titulok menu\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] chyba, nedefinovan� n�zov s�boru\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] chyba, '%s' nie je oby�ajn� s�bor\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] chyba, nedefinovan� titulok menu\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] chyba, nedefinovan� titulok menu\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] chyba, nedefinovan� titulok menu\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] chyba, nedefinovan� adres�r\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] chyba, '%s' nie je adres�r\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] chyba, '%s' neexistuje\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] chyba, nedefinovan� titulok menu\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# W: %4d x H: %4d

