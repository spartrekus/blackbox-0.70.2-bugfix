$set 7 #Slit

$ #SlitTitle
# Slit
$ #SlitDirection
# Smer Slitu
$ #SlitPlacement
# Umiestnenie Slitu
