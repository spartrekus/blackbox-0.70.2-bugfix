$set 1 #BaseDisplay

$ #XError
# %s:  X chyba: %s(%d) opera�n� k�dy %d/%d\n  zdroj 0x%lx\n
$ #SignalCaught
# %s: prijat� sign�l %d\n
$ #ShuttingDown
# ukon�uje sa\n
$ #Aborting
# preru�uje sa... v�pis obsahu pam�te (dumping core)\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: zlyhalo pripojenie k X serveru\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: nie je mo�n� ozna�i� pripojenie k obrazovke ako close-on-exec\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): odstra�uje sa chybn� okno z fronty udalost�\n
