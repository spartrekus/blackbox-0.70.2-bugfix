$set 12 #Workspacemenu

$ #WorkspacesTitle
# T��lauad
$ #NewWorkspace
# Uus t��laud
$ #RemoveLast
# Eemalda viimane
