$set 14 #main

$ #RCRequiresArg
# viga: '-rc' vajab argumenti\n
$ #DISPLAYRequiresArg
# viga: '-display' vajab argumenti\n
$ #WarnDisplaySet
# hoiatus: ei saanud m��rata keskonna muutujat 'DISPLAY'\n
$ #Usage
# Blackbox %s : (c) 2001 - 2002 Sean 'Shaleh' Perry\n\
  \t\t\t 1997 - 2000, 2002 Brad Hughes\n\n\
  -display <string>\t\tkasuta displei �hendust.\n\
  -rc <string>\t\t\tkasuta alternatiivseid resursse.\n\
  -version\t\t\tn�ita versiooninumber ja v�lju.\n\
  -help\t\t\t\tn�ita seda abiteksti ja v�lju.\n\n
$ #CompileOptions
# Kompileerimisoptsioonid:\n\
  Debuggimine\t\t\t%s\n\
  Kuju:\t\t\t%s\n\
  8bpp m��ratud teravustamine:\t%s\n\n
