$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: ei leidnud hallatavaid displeisid, katkestame\n
$ #MapRequest
# Blackbox::process_event: MapRequest 0x%lx'le\n
