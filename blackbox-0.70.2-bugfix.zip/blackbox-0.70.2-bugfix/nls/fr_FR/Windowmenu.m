$set 10 #Windowmenu

$ #SendTo
# Envoie vers ...
$ #Shade
# Fant�me
$ #Iconify
# Iconifie
$ #Maximize
# Maximise
$ #Raise
# �l�ve
$ #Lower
# Abaisse
$ #Stick
# �pingle
$ #KillClient
# Massacre
$ #Close
# Ferme
