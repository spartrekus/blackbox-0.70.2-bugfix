$set 8 #Toolbar

$ #NoStrftimeLength
# 00:00000
$ #NoStrftimeDateFormat
# %02d/%02d/%02d
$ #NoStrftimeDateFormatEu
# %02d.%02d.%02d
$ #NoStrftimeTimeFormat24
#  %02d:%02d 
$ #NoStrftimeTimeFormat12
# %02d:%02d %sm
$ #NoStrftimeTimeFormatP
# p
$ #NoStrftimeTimeFormatA
# a
$ #ToolbarTitle
# Barre d'outils
$ #EditWkspcName
# Edition du nom de l'espace courant
$ #ToolbarPlacement
# Disposition de la barre d'outils
