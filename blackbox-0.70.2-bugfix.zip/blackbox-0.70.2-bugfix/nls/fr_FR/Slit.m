$set 7 #Slit

$ #SlitTitle
# Fente
$ #SlitDirection
# Orientation de la Fente
$ #SlitPlacement
# Disposition de la Fente
