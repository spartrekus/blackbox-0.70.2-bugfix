$set 12 #Workspacemenu

$ #WorkspacesTitle
# Espaces de travail
$ #NewWorkspace
# Nouvel espace de travail
$ #RemoveLast
# Supprimer le dernier
