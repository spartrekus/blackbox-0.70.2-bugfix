$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: Erreur survenue pendant une requ�te adress�e au serveur X.\n  \
Un autre gestionnaire de fen�tres est d�j� lanc� %s.\n
$ #ManagingScreen
# BScreen::BScreen: Gestion de l'�cran %d avec le mode visuel 0x%lx, profondeur %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): Impossible de charger la police de caract�res '%s'\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): Impossible de charger la police de caract�res initiale.\n
$ #EmptyMenuFile
# %s: Fichier de menu vide\n
$ #xterm
# xterm
$ #Restart
# Red�marrer
$ #Exit
# Sortie
$ #EXECError
# BScreen::parseMenuFile: [exec] Erreur, pas de libell� de menu et/ou de commande definie\n
$ #EXITError
# BScreen::parseMenuFile: [exit] Erreur, aucun libell� de menu d�fini\n
$ #STYLEError
# BScreen::parseMenuFile: [style] Erreur, pas libell� de menu et/ou de nom de fichier\
defini\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] Erreur, aucun libell� de menu d�fini\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] Erreur, aucun nom de fichier d�fini\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] Erreur, '%s' est un fichier invalide\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] Erreur, aucun libell� de menu d�fini\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] Erreur, aucun libell� de menu d�fini\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] Erreur, aucun libell� de menu d�fini\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] Erreur, aucun r�pertoire d�fini\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] Erreur, '%s' est un r�pertoire \
invalide\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] Erreur, '%s' est inexistant\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] Erreur, aucun libell� de menu d�fini\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# L: %4d x H: %4d

